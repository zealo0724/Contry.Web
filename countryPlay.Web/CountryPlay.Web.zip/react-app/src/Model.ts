﻿export interface Country {
    area: string;
    region: string;
    name: Name;
}

export interface Name {
    common: string;
}